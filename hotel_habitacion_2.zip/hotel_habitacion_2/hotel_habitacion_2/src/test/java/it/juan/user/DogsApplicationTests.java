package it.juan.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogsApplicationTests {

	@Test
	void contextLoads() {
	}

}
